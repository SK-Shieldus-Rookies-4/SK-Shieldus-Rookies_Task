package com.rookies4.myspringbootlab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringbootLabApplicationTests {

	@Test
	void contextLoads() {
	}

}
